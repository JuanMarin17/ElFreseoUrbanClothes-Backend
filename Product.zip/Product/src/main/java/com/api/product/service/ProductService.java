package com.api.product.service;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;

import com.api.product.dto.ProductRequestDTO;
import com.api.product.dto.ProductResponseDTO;
import com.api.product.dto.StockAlertDTO;

import com.api.product.entity.Brand;
import com.api.product.entity.Category;
import com.api.product.entity.Product;
import com.api.product.entity.ProductImage;
import com.api.product.entity.ProductVariant;

import com.api.product.exception.BadRequestException;
import com.api.product.exception.ConflictException;
import com.api.product.exception.ResourceNotFoundException;

import com.api.product.repository.BrandRepository;
import com.api.product.repository.CategoryRepository;
import com.api.product.repository.ProductRepository;

@Service
@RequiredArgsConstructor
public class ProductService {

    private final ProductRepository productRepository;
    private final BrandRepository brandRepository;
    private final CategoryRepository categoryRepository;
    private final StockAlertService stockAlertService;

    @Transactional
    public ProductResponseDTO createProduct(ProductRequestDTO dto) {

        validateProductRequest(dto);

        if (productRepository.existsByNameIgnoreCase(dto.getName())) {
            throw new ConflictException("El producto ya existe");
        }

        Brand brand = findBrand(dto.getBrandId());

        Product product = Product.builder()
                .name(dto.getName())
                .description(dto.getDescription())
                .brand(brand)
                .active(true)
                .build();

        product.setVariants(buildVariants(dto, product));
        product.setImages(buildImages(dto, product));
        product.setCategories(buildCategories(dto));

        Product savedProduct = productRepository.save(product);

        checkAndSendStockAlerts(savedProduct);

        return mapToResponse(savedProduct);
    }

    @Transactional
    public Optional<ProductResponseDTO> updateProduct(UUID id, ProductRequestDTO dto) {

        Optional<Product> optional = productRepository.findById(id);
        if (optional.isEmpty())
            return Optional.empty();

        Product product = optional.get();

        validateProductRequest(dto);

        if (!product.getName().equalsIgnoreCase(dto.getName()) &&
                productRepository.existsByNameIgnoreCase(dto.getName())) {
            throw new ConflictException("Ya existe otro producto con el mismo nombre");
        }

        product.setName(dto.getName());
        product.setDescription(dto.getDescription());
        product.setBrand(findBrand(dto.getBrandId()));

        product.setVariants(buildVariants(dto, product));

        if (dto.getImages() != null && !dto.getImages().isEmpty()) {

            if (product.getImages() == null) {
                product.setImages(new ArrayList<>());
            }

            int currentImages = product.getImages().size();
            int newImagesCount = dto.getImages().size();

            if (currentImages + newImagesCount > 6) {
                throw new BadRequestException("No se pueden tener más de 6 imágenes por producto");
            }

            List<ProductImage> newImages = buildImages(dto, product);
            product.getImages().addAll(newImages);
        }

        product.setCategories(buildCategories(dto));

        Product savedProduct = productRepository.save(product);

        checkAndSendStockAlerts(savedProduct);

        return Optional.of(mapToResponse(savedProduct));
    }

    @Transactional(readOnly = true)
    public List<ProductResponseDTO> listProducts(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Product> productPage = productRepository.findAll(pageable);

        return productPage.getContent().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ProductResponseDTO> listActiveProducts(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Product> productPage = productRepository.findByActiveTrue(pageable);

        return productPage.getContent().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public Optional<ProductResponseDTO> getById(UUID id) {
        return productRepository.findById(id)
                .map(this::mapToResponse);
    }

    @Transactional
    public Optional<ProductResponseDTO> inactiveProduct(UUID id) {
        Optional<Product> optional = productRepository.findById(id);
        if (optional.isEmpty())
            return Optional.empty();

        Product product = optional.get();
        product.setActive(false);

        productRepository.save(product);
        return Optional.of(mapToResponse(product));
    }

    @Transactional
    public Optional<ProductResponseDTO> activeProduct(UUID id) {
        Optional<Product> optional = productRepository.findById(id);
        if (optional.isEmpty())
            return Optional.empty();

        Product product = optional.get();
        product.setActive(true);

        productRepository.save(product);
        return Optional.of(mapToResponse(product));
    }

    @Transactional(readOnly = true)
    public List<ProductResponseDTO> listAllProducts() {
        return productRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ProductResponseDTO> listAllActiveProducts() {
        return productRepository.findByActiveTrue().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ProductResponseDTO> listNewProducts() {
        OffsetDateTime oneWeekAgo = OffsetDateTime.now().minusDays(7);

        return productRepository.findByCreatedAtAfter(oneWeekAgo).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ProductResponseDTO> listNewActiveProducts() {
        OffsetDateTime oneWeekAgo = OffsetDateTime.now().minusDays(7);

        return productRepository.findByActiveTrueAndCreatedAtAfter(oneWeekAgo).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    private void validateProductRequest(ProductRequestDTO dto) {

        if (dto == null ||
                dto.getName() == null || dto.getName().isBlank() ||
                dto.getVariants() == null || dto.getVariants().isEmpty()) {
            throw new BadRequestException("Datos obligatorios faltantes");
        }

        if (dto.getImages() != null && dto.getImages().size() > 6) {
            throw new BadRequestException("Solo se permiten máximo 6 imágenes por producto");
        }

        if (dto.getImages() != null &&
                dto.getImages().stream().distinct().count() != dto.getImages().size()) {
            throw new ConflictException("No se permiten imágenes repetidas");
        }

        dto.getVariants().forEach(v -> {

            if (v.getSku() == null || v.getSku().isBlank()) {
                throw new BadRequestException("SKU inválido en variantes");
            }

            if (v.getPrice() == null || v.getPrice().doubleValue() <= 0) {
                throw new BadRequestException("Precio inválido en variantes");
            }

            if (v.getStock() == null || v.getStock() < 0) {
                throw new BadRequestException("Stock inválido en variantes");
            }

            if (v.getMinStock() == null || v.getMinStock() < 0) {
                throw new BadRequestException("minStock inválido en variantes");
            }
        });
    }

    private Brand findBrand(UUID brandId) {
        if (brandId == null)
            return null;

        return brandRepository.findById(brandId)
                .orElseThrow(() -> new ResourceNotFoundException("Marca no encontrada"));
    }

    private List<ProductVariant> buildVariants(ProductRequestDTO dto, Product product) {
        return dto.getVariants().stream()
                .map(v -> ProductVariant.builder()
                        .sku(v.getSku())
                        .price(v.getPrice())
                        .stock(v.getStock())
                        .minStock(v.getMinStock())
                        .product(product)
                        .build())
                .collect(Collectors.toList());
    }

    private List<ProductImage> buildImages(ProductRequestDTO dto, Product product) {

        List<ProductImage> images = new ArrayList<>();

        if (dto.getImages() == null || dto.getImages().isEmpty()) {
            return images;
        }

        if (dto.getImages().size() > 6) {
            throw new BadRequestException("Solo se permiten máximo 6 imágenes por producto");
        }

        dto.getImages().forEach(url -> {

            if (url == null || url.isBlank()) {
                throw new BadRequestException("URL de imagen inválida");
            }

            ProductImage image = ProductImage.builder()
                    .url(url)
                    .product(product)
                    .build();

            images.add(image);
        });

        return images;
    }

    private List<Category> buildCategories(ProductRequestDTO dto) {

        if (dto.getCategoryIds() == null || dto.getCategoryIds().isEmpty()) {
            return new ArrayList<>();
        }

        List<Category> categories = categoryRepository.findAllById(dto.getCategoryIds());

        if (categories.isEmpty()) {
            throw new ResourceNotFoundException("Categorías no encontradas");
        }

        return categories;
    }

    private void checkAndSendStockAlerts(Product product) {

        if (product.getVariants() == null || product.getVariants().isEmpty()) {
            return;
        }

        product.getVariants().forEach(variant -> {

            if (variant.getStock() <= variant.getMinStock()) {

                stockAlertService.sendAlert(
                        StockAlertDTO.builder()
                                .productId(product.getProductId())
                                .productName(product.getName())
                                .variantId(variant.getVariantId())
                                .sku(variant.getSku())
                                .stock(variant.getStock())
                                .minStock(variant.getMinStock())
                                .message("⚠️ Stock bajo: " + product.getName()
                                        + " (SKU: " + variant.getSku() + ")")
                                .timestamp(OffsetDateTime.now())
                                .build());
            }
        });
    }

    private ProductResponseDTO mapToResponse(Product product) {

        List<ProductVariant> variantList = product.getVariants() == null
                ? new ArrayList<>()
                : product.getVariants();

        List<ProductResponseDTO.VariantDTO> variants = variantList.stream()
                .map(v -> ProductResponseDTO.VariantDTO.builder()
                        .sku(v.getSku())
                        .price(v.getPrice())
                        .stock(v.getStock())
                        .minStock(v.getMinStock())
                        .build())
                .collect(Collectors.toList());

        List<ProductResponseDTO.ImageDTO> images = product.getImages() != null
                ? product.getImages().stream()
                        .map(i -> ProductResponseDTO.ImageDTO.builder()
                                .url(i.getUrl())
                                .build())
                        .collect(Collectors.toList())
                : new ArrayList<>();

        List<String> categories = product.getCategories() != null
                ? product.getCategories().stream()
                        .map(Category::getName)
                        .collect(Collectors.toList())
                : new ArrayList<>();

        return ProductResponseDTO.builder()
                .productId(product.getProductId())
                .name(product.getName())
                .description(product.getDescription())
                .brandName(product.getBrand() != null ? product.getBrand().getName() : null)
                .createdAt(product.getCreatedAt())
                .status(product.getActive() ? "ACTIVE" : "INACTIVE")
                .variants(variants)
                .images(images)
                .categories(categories)
                .build();
    }
}