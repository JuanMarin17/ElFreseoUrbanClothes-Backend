package com.api.Store.service;

import com.api.Store.client.UserClient;
import com.api.Store.dto.StoreUserRequestDTO;
import com.api.Store.dto.StoreUserResponseDTO;
import com.api.Store.entity.StoreUser;
import com.api.Store.enums.StoreRole;
import com.api.Store.exception.InvalidRoleException;
import com.api.Store.exception.StoreNotFoundException;
import com.api.Store.exception.UserAlreadyInStoreException;
import com.api.Store.repository.StoreRepository;
import com.api.Store.repository.StoreUserRepository;
import com.api.Store.util.HeaderUtil;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class StoreUserService {

    private final StoreRepository storeRepository;
    private final StoreUserRepository storeUserRepository;
    private final HeaderUtil headerUtil;
    private final UserClient userClient;

    // ── 1. Agregar usuario a tienda ──────────────────────────────────────────
    @Transactional
    public StoreUserResponseDTO addUserToStore(StoreUserRequestDTO dto) {

        UUID userId = headerUtil.getUserIdFromHeader().orElseThrow(() -> new RuntimeException("Usuario no autenticado"));
        dto.setUserId(userId);

        if(!userClient.existUser(userId)){
            throw new RuntimeException("Usuario no encontrado");
        }

        UUID storeId = headerUtil.getStoreIdFromHeader().orElseThrow(()-> new RuntimeException("El id de la tienda es obligatorio"));

        dto.setStoreId(storeId);

        if (!storeRepository.existsById(dto.getStoreId()))
            throw new StoreNotFoundException("Tienda no encontrada con id: " + dto.getStoreId());

        if (storeUserRepository.existsByIdUserIdAndIdStoreId(dto.getUserId(), dto.getStoreId()))
            throw new UserAlreadyInStoreException("El usuario ya pertenece a esta tienda");

        // OWNER solo se asigna automáticamente al crear la tienda
        if (dto.getRole() == StoreRole.OWNER)
            throw new InvalidRoleException(
                    "No se puede asignar el rol OWNER manualmente. Se asigna al crear la tienda.");

        StoreUser storeUser = StoreUser.builder()
                .id(new StoreUser.StoreUserId(dto.getStoreId(), dto.getUserId()))
                .role(dto.getRole())
                .build();

        storeUserRepository.save(storeUser);

        return toResponse(storeUser);
    }

    // ── 2. Usuarios de una tienda ────────────────────────────────────────────
    public List<StoreUserResponseDTO> getUsersByStore(UUID storeId) {
        if (!storeRepository.existsById(storeId))
            throw new StoreNotFoundException("Tienda no encontrada con id: " + storeId);

        return storeUserRepository.findByIdStoreId(storeId)
                .stream()
                .map(this::toResponse)
                .toList();
    }

    // ── 3. Tiendas de un usuario ─────────────────────────────────────────────
    public List<StoreUserResponseDTO> getStoresByUser(UUID userId) {
        return storeUserRepository.findByIdUserId(userId)
                .stream()
                .map(this::toResponse)
                .toList();
    }

    // ── 4. Validar acceso de un usuario a una tienda ─────────────────────────
    public boolean validateAccess(UUID userId, UUID storeId) {
        return storeUserRepository.existsByIdUserIdAndIdStoreId(userId, storeId);
    }

    // ── Mapper ───────────────────────────────────────────────────────────────
    private StoreUserResponseDTO toResponse(StoreUser u) {
        return StoreUserResponseDTO.builder()
                .userId(u.getId().getUserId())
                .storeId(u.getId().getStoreId())
                .role(u.getRole())
                .build();
    }
}
